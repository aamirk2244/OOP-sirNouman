#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;
int main(){
	std::vector<double> v1;
	std::vector<double> v2;
	for (int i = 0; i < 8; i++)
	{
		double x;
		std::cout << "Enter the value to the vector " << std::endl;
		std::cin >> x; 
		v1.push_back(x);
	}
	
	for (auto i = v1.begin(); i != v1.end(); i++)
	{
		std::cout << *i << " ";
	}
	std::cout << "\n";
	std::sort(v1.begin(), v1.end());
	std::cout << "After sorting in ascending order "<< std::endl;
	for (auto i = v1.begin(); i != v1.end(); i++)
	{
		std::cout << *i << " ";
	}
	std::cout << "\n\n";
	std::cout << "Now removing the repeated value " << std::endl;
	for (int i = 0; i < 8; i++)
	{
		auto last = unique(v1.begin(), v1.end());
		v1.erase(last, v1.end());
	}
	
	std::cout << "\n\n";
	for (auto i = v1.begin(); i != v1.end(); i++)
	{
		std::cout << *i << " ";
	}
	
	std::cout<<"\n\nNow the central value of the vector " << std::endl;
	int x1 = v1.size();
	if (x1 % 2 == 0)
	{
		int x2 = floor(x1 / 2) ; 
		//x2 = x2 - 1;
		std::cout << "these are the central value of the vector  ==  " << v1[x2-1] <<"   and    " << v1[x2] <<   std::endl;
		
	}
	
	else
	{
		int x2 = floor(x1/2);
		std::cout << "This is the central value of the vector  ==   " << v1[x2] << std::endl;
	}
	
	std::cout << "_____________________________________________________________________________________________" << std::endl;
	std::cout << "NOw Moving to another vector " << std::endl;
	std::cout << "_____________________________________________________________________________________________" << std::endl;
	
	std::cout << "\n\n " ;
	for (int i = 0; i < 8 ; i++)
	{
		double y2;
		std::cout << "Enter value to the vector " << std::endl;
		
		std::cin >> y2;
		v2.push_back(y2);
	 } 
	 std::cout << "This is the vector " << std::endl;
	 for (double y9 : v2)
	 {
	 	std::cout << y9 << " ";
	 }
	 std::cout <<"\n\nNow sorting the vector in ascending order " << std::endl;
	 std::sort(v2.begin(), v2.end());
	 for (double n2 : v2)
	 {
	 	std::cout << n2 << " ";
	 }
	 std::cout <<"\n\n Now Remving the repeated values from the vector " << std::endl;
	 
	 for (int i = 0; i < 8; i++)
	 {
	 	auto last2 = unique(v2.begin(), v2.end());
	 	v2.erase(last2, v2.end());
	 }
	 
	 for (double vec2 : v2)
	 {
	 	std::cout << vec2 << " " ;
	 }
	 
	 std::cout << "\n\nNow finding the middle value of the vector  " << std::endl;
	 int vv = v2.size();
	 if (vv % 2 == 0)
	 {
	 	int x = vv/2;
	 	int x2 = (vv/2) - 1;
	 	std::cout << "tHese are the middle values of the vector   " << x << "    and    " << x2 << std::endl; 
	 }
	 else
	 {
	 	floor(vv);
	 	std::cout << "This is the middle value of the vector  -->>   " << vv << std::endl; 
	 }
	 std::cout << "\n\n __________________________________________The End_____________________________________ " << std::endl;
	 
	std::cin.get();
	return 0;
}
