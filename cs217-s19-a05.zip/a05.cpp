#include <iostream> 
using namespace std; 

// stuff from Queue lecture goes here ... then apply template on it 




class Writer { 
    // fill stuff here 
}; 
// method definitions for Writer class here 



class Reader { 
    // fill stuff  here 
};
// method definitions for Reader class here 





int main() { 
    Queue<string> *que; 
    que = new Queue<string>; 

    string filename = "string-collection.txt"; 

    Writer first_writer; 
    Reader first_reader; 

    first_writer.process_file(filename, que); 
    first_reader.process_queue(que); 

    return 0; 
}



